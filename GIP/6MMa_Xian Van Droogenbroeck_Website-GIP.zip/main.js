/*Page Loader*/
document.addEventListener("DOMContentLoaded", function(event) {
    document.getElementById("loader-container").style.display = "block";

    window.addEventListener("load", function() {
        document.getElementById("loader-container").style.display = "none";
    });
});

/*Landingpage plant*/
document.addEventListener('scroll', function() {
    const plantElement = document.querySelector('.landing-page-plant img');
    const maxScroll = window.innerHeight;
    const scrollPosition = window.scrollY;
    const opacity = 0.7 - (scrollPosition / maxScroll);

    plantElement.style.opacity = Math.max(opacity, 0);
});

/*Gallery*/
document.addEventListener("DOMContentLoaded", function() {
    const gallery = document.querySelectorAll('.gallery img');
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const closeBtn = document.querySelector('.close');

    gallery.forEach(img => {
        img.addEventListener('click', function() {
            lightbox.style.display = 'block';
            lightboxImg.src = this.src;
            lightboxImg.style.height = '90vh';
            lightboxImg.style.width = 'auto';
        });

        img.addEventListener('mousemove', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            this.style.transform = `translate(${(x - rect.width / 2) / 20}px, ${(y - rect.height / 2) / 20}px)`;
        });

        img.addEventListener('mouseleave', function() {
            this.style.transform = 'translate(0, 0)';
        });
    });

    closeBtn.addEventListener('click', function() {
        lightbox.style.display = 'none';
    });

    lightbox.addEventListener('click', function(e) {
        if (e.target !== lightboxImg) {
            lightbox.style.display = 'none';
        }
    });
});

/*Filter buttons*/
document.addEventListener('DOMContentLoaded', () => {
    const filterInput = document.getElementById('filterInput');
    const itemsList = document.getElementById('itemsList');
    const items = itemsList.getElementsByTagName('li');
    const buttons = document.querySelectorAll('.filter-buttons button');

    filterInput.addEventListener('keyup', filterItems);
    buttons.forEach(button => button.addEventListener('click', filterByCategory));

    function filterItems() {
        const filterValue = filterInput.value.toLowerCase();

        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            const itemKeywords = item.getAttribute('data-keywords') ? item.getAttribute('data-keywords').toLowerCase() : '';

            if (itemKeywords.includes(filterValue)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        }
    }

    function filterByCategory(e) {
        const category = e.target.getAttribute('data-filter');
        filterInput.value = ''; 

        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            if (category === 'alles' || item.getAttribute('data-category') === category) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        }
    }
});

/*Video afspelen*/
window.onload = function(){
    let player = document.getElementById("player"),
        play = document.getElementById("play");
    
    play.addEventListener("click", function(){
        player.play();
        this.style.display = "none";
    });

    player.addEventListener("click", function(){
        player.pause();
        play.style.display = "block";
    });
}

/*Contactpage*/
document.querySelectorAll('.form-control').forEach(input => {
    const placeholder = input.getAttribute('placeholder');
    input.addEventListener('focus', () => {
        input.setAttribute('placeholder', '');
    });
    input.addEventListener('blur', () => {
        input.setAttribute('placeholder', placeholder);
    });
});

/*Hamburger*/
document.addEventListener('DOMContentLoaded', function () {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.navbar-links');
    const body = document.body;

    hamburger.addEventListener('click', function () {
        const isActive = navLinks.parentElement.classList.toggle('active');
        if (isActive) {
            body.classList.add('no-scroll');
        } else {
            body.classList.remove('no-scroll');
        }
    });
});